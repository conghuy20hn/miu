/**
 * Created by conghuyvn8x on 2/16/2019.
 */
var redis = require('../config/redis').conRedis;
const dbChat = require('../config/redis').dbChat;
const keyRedis = require('../config/redis').keyRedis;
const VTHelper = require('../lib/VTHelper');
const moment = require('moment-timezone');

exports.saveChat = async function (data) {
    "use strict";
    console.log('saveChat',data);

    let val = await new Promise(function (resolve, reject) {
        redis.select(dbChat);
        data.time=moment().tz('Asia/Ho_Chi_Minh').format();

        let strData = JSON.stringify(data);
        let check = redis.lpush(keyRedis.wdChat, strData);
        if (check == true) {
            resolve(true);
        } else {
            reject(false);
        }
    });
    return val;
}

exports.getListChat = async function () {
    "use strict";
    redis.select(dbChat);
    let stop = await VTHelper.llen(keyRedis.wdChat, dbChat);
    console.log('getListChat', keyRedis.wdChat, dbChat, stop);
    let data = false;
    if(stop!==false){
        data = await VTHelper.getLrange(keyRedis.wdChat,0,stop, dbChat);
    }
    return data;
}