/**
 * Created by conghuyvn8x on 12/25/2018.
 */
var redis = require('redis');

const port = 6379;
const host = 'localhost';
const dbChat = 1;
var client = redis.createClient(port, host);
const keyRedis = {
    wdChat:"WD:CHAT"
}

exports.conRedis = client;
exports.dbChat = dbChat;
exports.keyRedis = keyRedis;