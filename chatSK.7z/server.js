/**
 * Created by conghuyvn8x on 8/1/2018.
 */
var express = require('express');
var socket = require('socket.io');

// App setup
var app = express();
var server = app.listen(9100, function () {
    console.log('listening to request on port 9100');
});

// static file
app.use(express.static('public'));

// Socket setup
var io = socket(server);
var chatModel = require('./model/chatModel');

io.on('connection', function (socket) {
    console.log('make socket connection', socket.id);
    var clientIp = socket.handshake.address.replace(/^.*:/, '');

    socket.on('chat', function (data) {
        console.log('make socket connection chat', socket.id);
        data.ip = clientIp;
        // luu vao redis
        chatModel.saveChat(data);
        io.sockets.emit('chat', data);
    });

    socket.on('typing', function (data) {
        socket.broadcast.emit('typing', data);
    });

    socket.on('onLoadListData', async function (data) {
        console.log('make socket connection onLoadListData', socket.id);
        let listData = await chatModel.getListChat();
        console.log('onLoadListData',listData);

        var dataResult = [];
        if(listData.length){
            listData.forEach(function (item) {
                dataResult.push(JSON.parse(item));
            })
        }else{
            dataResult=null;
        }
        io.sockets.emit('onLoadListData', dataResult);
    });


});