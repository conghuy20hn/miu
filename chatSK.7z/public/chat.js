/**
 * Created by conghuyvn8x on 8/1/2018.
 */
// make connect
var socket = io.connect('http://10.240.197.50:9100');
var message = document.getElementById('message');
handle = document.getElementById('handle');
btn = document.getElementById('send');
output = document.getElementById('output');
feedback = document.getElementById('feedback');

window.onload = function() {
    console.log('onload');
    socket.emit("onLoadListData", {});
};

// emit event
btn.addEventListener('click', function () {
    socket.emit('chat', {
        message: message.value,
        handle: handle.value,
    });
});

// listen for event
socket.on('chat', function (data) {
    feedback.innerHTML = '';
    output.innerHTML += '<p><b>' + data.handle + '</b>: ' + data.message + "</p>";
});

message.addEventListener('keypress', function () {
    socket.emit('typing', handle.value);
});

socket.on('typing', function (data) {
    feedback.innerHTML = '<p>' + data + ' is typing...</p>';
});


socket.on('onLoadListData', function (data) {
    console.log('onLoadListData', data);
    feedback.innerHTML = '';
    if(data.length>0){
        data.forEach(function (item) {
            output.innerHTML += '<p><b>' + item.handle + '</b>: ' + item.message + "</p>";
        })
    }
});



