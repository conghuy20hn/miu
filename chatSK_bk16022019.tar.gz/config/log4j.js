/**
 * Created by conghuyvn8x on 8/5/2018.
 */
const log4js = require('log4js');

log4js.configure({
    appenders: {GameVT: {type: 'file', filename: './GameVT/logs/GameVT.log'}},
    categories: {default: {appenders: ['GameVT'], level: 'all'}}
});
var logger = log4js.getLogger('GameVT');
exports.logger = logger;