/**
 * Created by conghuyvn8x on 8/5/2018.
 */
const log4js = require('log4js');

log4js.configure({
    appenders: {
        GameVT: {type: 'dateFile', filename: './logs/error.log', pattern: '.yyyy-MM-dd', compress: true},
        logAuth: {type: 'dateFile', filename: './logs/authen.log', pattern: '.yyyy-MM-dd', compress: true},
        logValid: {type: 'dateFile', filename: './logs/validation.log', pattern: '.yyyy-MM-dd', compress: true},
        logResponse: {type: 'dateFile', filename: './logs/response.log', pattern: '.yyyy-MM-dd', compress: true},
        err: {type: 'dateFile', filename: './logs/error.log', pattern: '.yyyy-MM-dd', compress: true}
    },
    categories: {
        default: {appenders: ['GameVT'], level: 'all'},
        logAuth: {appenders: ['logAuth'], level: 'all'},
        logValid: {appenders: ['logValid'], level: 'all'},
        logErr: {appenders: ['err'], level: 'all'},
        logResponse: {appenders: ['logResponse'], level: 'all'}
    }
});
var logger = log4js.getLogger('GameVT');
var logAuth = log4js.getLogger('logAuth');
var logValid = log4js.getLogger('logValid');
var logResponse = log4js.getLogger('logResponse');
var logErr = log4js.getLogger('logErr');

exports.logger = logger;
exports.logAuth = logAuth;
exports.logValid = logValid;
exports.logResponse = logResponse;
exports.logErr = logErr;