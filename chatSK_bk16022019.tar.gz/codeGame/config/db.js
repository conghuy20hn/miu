/**
 * Created by conghuyvn8x on 8/4/2018.
 */
var mysql = require('mysql');

const mysql_pool  = mysql.createPool({
    connectionLimit : 100,
    host: 'localhost',
    user: 'dev',
    password: 'abc@1234!',
    database: 'beminhon'
});

exports.conn = mysql_pool;
