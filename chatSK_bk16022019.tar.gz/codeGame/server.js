/**
 * Created by conghuyvn8x on 12/25/2018.
 */
// call the packages we need
var express = require('express');        // call express
var app = express();                 // define our app using express
// config access log
var morgan  = require('morgan');
var path = require('path');
var rfs = require('rotating-file-stream');
const moment = require('moment-timezone');
morgan.token('date', (req, res, tz) => {
    return moment().tz(tz).format();
})

morgan.token('response-time', function (req, res) {
    if (!res._header || !req._startAt) return '';
    var diff = process.hrtime(req._startAt);
    var ms = diff[0] * 1e3 + diff[1] * 1e-6;
    ms = ms.toFixed(3);
    //var timeLength = 8; // length of final string
    // format result:
    var arrMs=ms.split('.');
    return arrMs[0];
    //return ('' + ms).length > timeLength ? ms : repeatStr(' ', timeLength - ('' + ms).length) + ms;
})

// create a rotating write stream
var accessLogStream = rfs('access.log', {
    interval: '1d', // rotate daily
    path: path.join(__dirname, 'logs')
});
var log_format = ':remote-addr :remote-user [:date[Asia/Ho_Chi_Minh]] ":method :url HTTP/:http-version" :status :res[content-length] ":referrer" ":user-agent" - :response-time ms';
app.use(morgan(log_format, { stream: accessLogStream }));
// end config access log
// configure app to use bodyParser()
// this will let us get the data from a POST
var bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({extended: true}));
// Response type for SOAP
//body parser middleware are supported (optional)
app.use(bodyParser.raw({type: function(){return true;}, limit: '5mb'}));
app.use(bodyParser.json());
app.use(bodyParser.text());

var port = process.env.PORT || 8081;        // set our port

// ROUTES FOR OUR API
// =============================================================================

var routes = require('./routes/routes'); //importing route
routes(app); //register the route

//var router = express.Router();              // get an instance of the express Router
//
//// test route to make sure everything is working (accessed at GET http://localhost:8080/api)
//router.get('/', function (req, res) {
//    res.json({message: 'GameVT API!'});
//});
//
//// more routes for our API will happen here
//
//// REGISTER OUR ROUTES -------------------------------
//// all of our routes will be prefixed with /api
//app.use('/routes/routes', router);

// START THE SERVER
// =============================================================================
// Config for SOAP
var soap = require('soap');
var service = require('./lib/soapHelper').services;
var xml = require('fs').readFileSync('./wsdl/myservice.wsdl', 'utf8');
// Start server
app.listen(port, function() {
    //Note: /gameTet route will be handled by soap module
    //and all other routes & middleware will continue to work
    soap.listen(app, '/gameTet', service, xml);
});
console.log('GameVT API on port ' + port);

