/**
 * Created by conghuyvn8x on 8/4/2018.
 */
var vtGameModel = require('../model/VtGameModel');
var validHelper = require('../lib/validHelper');
var VTHelper = require('../lib/VTHelper');
var logHelper = require('../lib/logHelper');
var get_ip = require('ipware')().get_ip;
var redis = require('../config/redis');
//const errorCode = {succ:'00',loginfail:'01',sysErr:'02',validErr:'03', overTurn:'04', VioBlacklist:'04'};
const errorCode = errCode = VTHelper.errCode;
const i18n = VTHelper.i18n;
var url = require('url');
/**
 * huync2: test
 * @type {async}
 */
exports.plusTurnsV2 = async function (req, res) {
    // trim du lieu truyen vao
    let data=await VTHelper.trimResParams(req.body);
    // valid du lieu dau vao
    let valid= await validHelper.validPlusTurns(data);
    if(valid!==true){
        logHelper.writeLog('valid','plusTurns',data,req,{data:null,errCode:errorCode.validErr,message:valid});
        res.jsonV2(null, errorCode.validErr, i18n.__('Lỗi validate, nhập sai dữ liệu.'));
    }else{
        let keyRedis = data.msisdn;
        vtGameModel.plusTurnsV2(data, keyRedis, function (result) {
            if (result) {
                res.jsonV2({result: result}, errorCode.succ, 'Success.');
            } else {
                res.jsonV2({result: result}, 1, 'Hệ thống bận.');
                //res.jsonV2(data, 1, 'Hệ thống bận.');
            }
        });
    }
};

/**
 * huync2: cong luot choi
 * @type {async}
 */
exports.plusTurns = async function (req, res) {
    // trim du lieu truyen vao
    let data=await VTHelper.trimResParams(req.body);
    // check auth
    let checkAuth = await VTHelper.checkAuth(data,req);
    if(checkAuth.errorCode === errorCode.authFalse){
        logHelper.writeLog('auth','plusTurns',data,req,{data:null,errorCode:checkAuth.errorCode,message:checkAuth.message});
        res.jsonV2(null, errorCode.authFalse, checkAuth.message);
    }else{
        try{
            // valid du lieu dau vao
            let valid= await validHelper.validPlusTurns(data);
            if(valid!==true){
                logHelper.writeLog('valid','plusTurns',data,req,{data:null,errorCode:errorCode.validErr,message:valid});
                res.jsonV2(null, errorCode.validErr, i18n.__('Lỗi validate, nhập sai dữ liệu.'));
            }else{
                //var username = req.param('username');
                vtGameModel.plusTurns(data, await function (err, result) {
                    if (err===errorCode.sysErr) {
                        logHelper.writeLog('response','plusTurns',data,req,{data:null,errorCode:errorCode.sysErr,message:result});
                        res.jsonV2(null, errorCode.sysErr, result);
                    } else {
                        logHelper.writeLog('response','plusTurns',data,req,{data:{total_turn: result},errorCode:errorCode.succ,message:i18n.__('Thành công.')});
                        res.jsonV2({
                            total_turn: result
                        }, errorCode.succ, i18n.__('Thành công.'));
                    }
                });
            }
        }catch(e){
            logHelper.writeLog('valid','plusTurns',data,req,{data:null,errorCode:errorCode.sysErr,message: 'exception '+ e});
            res.jsonV2(null, errorCode.validErr, i18n.__('Lỗi hệ thống.'));
        }
    }
};

/**
 * huync2: tru luot
 * @type {async}
 */
exports.usingTurn = async function (req, res,next) {
    let data=await VTHelper.trimResParams(req.body);
    // check auth
    let checkAuth = await VTHelper.checkAuth(data,req);
    if(checkAuth.errorCode === errorCode.authFalse){
        logHelper.writeLog('auth','usingTurn',data,req,{data:null,errorCode:checkAuth.errorCode,message:checkAuth.message});
        res.jsonV2(null, errorCode.authFalse, checkAuth.message);
    }else{
        try{
            // valid du lieu dau vao
            let valid= await validHelper.validUsingTurn(data);
            if(valid!==true){
                logHelper.writeLog('valid','usingTurn',data,req,{data:null,errorCode:errorCode.validErr,message:valid});
                res.jsonV2(null, errorCode.validErr, i18n.__('Lỗi validate, nhập sai dữ liệu.'));
            }else{
                //var username = req.param('username');
                vtGameModel.usingTurn(data, await function (err, total) {
                    if (err===errorCode.sysErr) {
                        logHelper.writeLog('response','usingTurn',data,req,{data:null,errorCode:err,message:i18n.__('Hệ thống bận.')});
                        res.jsonV2(null, errorCode.sysErr, i18n.__('Hệ thống bận.'));
                    } else if(err===errorCode.VioBlacklistUsingTurn){
                        logHelper.writeLog('response','usingTurn',data,req,{data:null,errorCode:err,message:i18n.__('Thuê bao bị chặn do vi phạm thể lệ chương trình')});
                        res.jsonV2(null, errorCode.VioBlacklistUsingTurn, i18n.__('Thuê bao bị chặn do vi phạm thể lệ chương trình'));
                    }else if(err===errorCode.overTurn){
                        logHelper.writeLog('response','usingTurn',data,req,{data:null,errorCode:err,message:i18n.__('Hết lượt.')});
                        res.jsonV2(null, errorCode.overTurn, i18n.__('Hết lượt.'));
                    } else {
                        logHelper.writeLog('response','usingTurn',data,req,{data:{total_turn: total},errorCode:errorCode.succ,message:i18n.__('Thành công.')});
                        res.jsonV2({
                            total_turn: total
                        }, errorCode.succ, i18n.__('Thành công.'));
                    }
                });
            }
        }catch(e){
            logHelper.writeLog('valid','usingTurn',data,req,{data:null,errorCode:errorCode.sysErr,message: 'exception '+ e});
            res.jsonV2(null, errorCode.validErr, i18n.__('Lỗi hệ thống.'));
        }
    }
};

/**
 * huync2: luu log
 * @type {async}
 */
exports.addLogs = async function (req, res) {
    let data=await VTHelper.trimResParams(req.body);
    // check auth
    let checkAuth = await VTHelper.checkAuth(data,req);
    if(checkAuth.errorCode === errorCode.authFalse){
        logHelper.writeLog('auth','addLogs',data,req,{data:null,errorCode:checkAuth.errorCode,message:checkAuth.message});
        res.jsonV2(null, errorCode.authFalse, checkAuth.message);
    }else{
        try{
            // valid du lieu dau vao
            let valid= await validHelper.validAddLogs(data);
            if(valid!==true){
                logHelper.writeLog('valid','addLogs',data,req,{data:null,errorCode:errorCode.validErr,message:valid});
                res.jsonV2(null, errorCode.validErr, i18n.__('Lỗi validate, nhập sai dữ liệu.'));
            }else{
                vtGameModel.addLogs(data, await function (err, result) {
                    if (err===errorCode.sysErr) {
                        logHelper.writeLog('response','addLogs',data,req,{data:null,errorCode:err,message:i18n.__('Hệ thống bận.')});
                        res.jsonV2(null, errorCode.sysErr, i18n.__('Hệ thống bận.'));
                    } else {
                        logHelper.writeLog('response','addLogs',data,req,{data:null,errorCode:err,message:i18n.__('Thành công.')});
                        res.jsonV2(null, errorCode.succ, i18n.__('Thành công.'));
                    }
                });
            }
        }catch(e){
            logHelper.writeLog('valid','addLogs',data,req,{data:null,errorCode:errorCode.sysErr,message: 'exception '+ e});
            res.jsonV2(null, errorCode.validErr, i18n.__('Lỗi hệ thống.'));
        }
    }
};

/**
 * huync2: lay luot choi
 * @type {async}
 */
exports.getTurns = async function (req, res) {
    let data=await VTHelper.trimResParams(req.body);
    // check auth
    let checkAuth = await VTHelper.checkAuth(data,req);
    if(checkAuth.errorCode === errorCode.authFalse){
        logHelper.writeLog('auth','getTurns',data,req,{data:null,errorCode:checkAuth.errorCode,message:checkAuth.message});
        res.jsonV2(null, errorCode.authFalse, checkAuth.message);
    }else{
        try{
            // valid du lieu dau vao
            let valid= await validHelper.validGetTurns(data);
            if(valid!==true){
                logHelper.writeLog('valid','getTurns',data,req,{data:null,errorCode:errorCode.validErr,message:valid});
                res.jsonV2(null, errorCode.validErr, i18n.__('Lỗi validate, nhập sai dữ liệu.'));
            }else{
                //var username = req.param('username');
                vtGameModel.getTurns(data, await function (err, result) {
                    //console.log('getTurns',err);
                    if (err===errorCode.sysErr) {
                        logHelper.writeLog('response','getTurns',data,req,{data:null,errorCode:errorCode.VioBlacklist,message:result});
                        res.jsonV2(null, errorCode.sysErr, result);
                    } else
                    if (err===errorCode.VioBlacklist) {
                        logHelper.writeLog('response','getTurns',data,req,{data:null,errorCode:errorCode.VioBlacklist,message:result});
                        res.jsonV2(null, errorCode.VioBlacklist, result);
                    } else {
                        logHelper.writeLog('response','getTurns',data,req,{data:{total_turn: result},errorCode:errorCode.succ,message:i18n.__('Thành công.')});
                        res.jsonV2({
                            total_turn: result
                        }, errorCode.succ, i18n.__('Thành công.'));
                    }
                });
            }
        }catch(e){
            logHelper.writeLog('valid','getTurns',data,req,{data:null,errorCode:errorCode.sysErr,message: 'exception '+ e});
            res.jsonV2(null, errorCode.validErr, i18n.__('Lỗi hệ thống.'));
        }
    }
};


/**
 * share FB
 * @param req
 * @param res
 */
exports.shareFb = async function (req, res) {
    let data=await VTHelper.trimResParams(req.body);
    let checkAuth = await VTHelper.checkAuth(data,req);
    if(checkAuth.errorCode === errorCode.authFalse){
        logHelper.writeLog('auth','shareFb',data,req,{data:null,errorCode:checkAuth.errorCode,message:checkAuth.message});
        res.jsonV2(null, errorCode.authFalse, checkAuth.message);
    }else {
        // valid du lieu dau vao
        let valid = await validHelper.validShareFb(data);
        if (valid !== true) {
            logHelper.writeLog('valid', 'shareFb', data, req, {
                data: null,
                errorCode: errorCode.validErr,
                message: valid
            });
            res.jsonV2(null, errorCode.validErr, i18n.__('Lỗi validate, nhập sai dữ liệu.'));
        } else {
            vtGameModel.shareFb(data, await function (err, result) {
                if (err == errorCode.succ) {
                    logHelper.writeLog('response', 'shareFb', data, req, {
                        data: null,
                        errorCode: errorCode.succ,
                        message: i18n.__('Thành công.')
                    });
                    res.jsonV2({total_turn: result}, errorCode.succ, i18n.__('Thành công.'));
                } else {
                    logHelper.writeLog('response', 'shareFb', data, req, {data: null, errorCode: err, message: result});
                    res.jsonV2(null, err, result);
                }
            });
        }
    }
};

/**
 * ham thuc hien kiem tra acc dã trúng quà đặc biệt chưa
 */
exports.checkGiftRewarded = async function (req, res) {
    let data =  VTHelper.trimResParams(req.body);
    let checkAuth = await VTHelper.checkAuth(data,req);
    if(checkAuth.errorCode === errorCode.authFalse){
        logHelper.writeLog('auth','checkGiftRewarded',data,req,{data:null,errorCode:checkAuth.errorCode,message:checkAuth.message});
        res.jsonV2(null, errorCode.authFalse, checkAuth.message);
    }else{
        if (data.hasOwnProperty('password')) {
            delete data.password;
        }
        let ip = get_ip(req).clientIp.replace(/^.*:/, '');
        data.ip=ip;
        vtGameModel.checkGiftRewarded(data, await function (err, result) {
            if (err === errorCode.succ) {
                logHelper.writeLog('response','checkGiftRewarded',data,req,{data:{sharerd: result},errorCode:errorCode.succ,message:i18n.__('Thành công.')});

                res.jsonV2({number:result}, errorCode.succ, i18n.__('Thành công.'));
            }else{
                logHelper.writeLog('response','checkGiftRewarded',data,req,{data:null,errorCode:errorCode.sysErr,message:result});
                res.jsonV2(null,err, result);
            }
        });

    }
};

/**
 * ham thuc hien lay danh sach bang vang
 */
exports.getGoldTable = async function (req, res) {
    let data=await VTHelper.trimResParams(req.body);
    // check auth
    let checkAuth = await VTHelper.checkAuth(data,req);
    if(checkAuth.errorCode === errorCode.authFalse){
        logHelper.writeLog('auth','getGoldTable',data,req,{data:null,errorCode:checkAuth.errorCode,message:checkAuth.message});
        res.jsonV2(null, errorCode.authFalse, checkAuth.message);
    }else {
        if (data.hasOwnProperty('password')) {
            delete data.password;
        }
        if (data.hasOwnProperty('username')) {
            delete data.username;
        }
        let ip = get_ip(req).clientIp.replace(/^.*:/, '');
        data.ip = ip;
        vtGameModel.getGoldTable(data, function (result) {
            if (result) {
                if (result.errorCode === errorCode.succ) {
                    res.json({errorCode: errorCode.succ, message: result.message, data: {items: result.data}});
                } else {
                    res.json({data: null, errorCode: result.errorCode, message: result.message});
                }
            } else {
                res.json({data: null, errorCode: errorCode.sysErr, message: result.message});
            }
        });
    }
};

/**
 * ham thuc hien lay lich su qua tang cua acc
 */
exports.getGiftList = async function (req, res) {
    let data=await VTHelper.trimResParams(req.body);
    // check auth
    let checkAuth = await VTHelper.checkAuth(data,req);
    if(checkAuth.errorCode === errorCode.authFalse){
        logHelper.writeLog('auth','getGiftList',data,req,{data:null,errorCode:checkAuth.errorCode,message:checkAuth.message});
        res.jsonV2(null, errorCode.authFalse, checkAuth.message);
    }else {
        if (data.hasOwnProperty('password')) {
            delete data.password;
        }
        if (data.hasOwnProperty('username')) {
            delete data.username;
        }
        let ip = get_ip(req).clientIp.replace(/^.*:/, '');
        data.ip = ip;
        vtGameModel.getGiftList(data, function (result) {
            if (result) {
                if (result.errorCode === errorCode.succ) {
                    res.json({errorCode: errorCode.succ, message: result.message, data: {items: result.data}});
                } else {
                    res.json({data: null, errorCode: result.errorCode, message: result.message});
                }

            } else {
                res.json({data: null, errorCode: errorCode.sysErr, message: result.message});
            }
        });
    }

};

/**
 * ham thuc hien kiem tra isdn da share facebook chua
 */
exports.checkShareFb = async function (req, res) {
    let data=await VTHelper.trimResParams(req.body);
    // check auth
    let checkAuth = await VTHelper.checkAuth(data,req);
    if(checkAuth.errorCode === errorCode.authFalse){
        logHelper.writeLog('auth','checkShareFb',data,req,{data:null,errorCode:checkAuth.errorCode,message:checkAuth.message});
        res.jsonV2(null, errorCode.authFalse, checkAuth.message);
    }else{
        // valid du lieu dau vao
        let valid= await validHelper.validCheckShareFb(data);
        if(valid!==true){
            logHelper.writeLog('valid','checkShareFb',data,req,{data:null,errorCode:errorCode.validErr,message:valid});
            res.jsonV2(null, errorCode.validErr, i18n.__('Lỗi validate, nhập sai dữ liệu.'));
        }else{
            vtGameModel.checkShareFb(data, await function (err, result) {
                if (err===errorCode.sysErr) {
                    logHelper.writeLog('response','checkShareFb',data,req,{data:null,errorCode:errorCode.sysErr,message:result});
                    res.jsonV2(null, errorCode.sysErr, result);
                }else{
                    logHelper.writeLog('response','checkShareFb',data,req,{data:{sharerd: result},errorCode:errorCode.succ,message:i18n.__('Thành công.')});
                    res.jsonV2({
                        shared: result
                    }, errorCode.succ, i18n.__('Thành công.'));
                }
            });
        }
    }
};
