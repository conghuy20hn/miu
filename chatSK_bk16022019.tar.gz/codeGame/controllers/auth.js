/**
 * Created by HUYNC2 on 1/4/2019.
 */
var VTHelper = require('../lib/VTHelper');
var logAuth = require('../config/log4j').logAuth;
var redisIsReady = require('../config/redis').redisIsReady;
var get_ip = require('ipware')().get_ip;
var validHelper = require('../lib/validHelper');
var logHelper = require('../lib/logHelper');
const async = require('async');
var url = require('url');

const errorCode = {succ:'00',loginfail:'01',sysErr:'02',validErr:'03', overTurn:'04', authFalse:'01'};

module.exports = function (options) {
    return async function (req, res, next) {
        let data= await VTHelper.trimResParams(req.body);
        //let data=[];
        //if(req.method=='POST'){
        //
        //    if(Object.keys(req.body).length>0){
        //data=await VTHelper.trimResParams(req.body);
        //    }else{
        //        let objData=(url.parse(req.url, true).query);
        //        data={
        //            username:objData.username,
        //            password:objData.password,
        //            serviceId:objData.serviceId
        //        };
        //    }
        //}else{
        //    let objData=(url.parse(req.url, true).query);
        //    data={
        //        username:objData.username,
        //        password:objData.password,
        //        serviceId:objData.serviceId
        //    };
        //}
        //
        //logHelper.writeLog('auth','auth',data,req,'checkrequest');

        try{
            //console.log('auth log ',url.parse(req.url, true).query);
            // trim du lieu truyen vao
            let ip=get_ip(req).clientIp.replace(/^.*:/, '');

            let checkValid= await validHelper.validAuth(data);
            if(checkValid!==true){
                logHelper.writeLog('auth','auth',data,req,{data:null,errCode:errorCode.authFalse,message:checkValid});
                res.jsonV2(null, errorCode.authFalse, 'Xác thực không thành công.');
            }else{
                // Implement the middleware function based on the options object
                let username = data.username.trim();
                let password = data.password.trim();
                let serviceId = data.serviceId.trim();

                //let ip=req.connection.remoteAddress;
                let check = await VTHelper.checkAuth(username, password,serviceId, ip);
                //console.log('auth',check);
                if(check===false){
                    // luu log
                    logHelper.writeLog('auth','auth',data,req,{data:null,errCode:errorCode.authFalse,message:'Xác thực không thành công.'});
                    res.jsonV2(null, errorCode.authFalse, 'Xác thực không thành công.');
                    //res.sendStatus(401);
                }else{
                    next();
                }
            }
            //}
        }catch(e){
            logHelper.writeLog('auth','auth',data,req,{data:null,errCode:errorCode.sysErr,message:"Lỗi hệ thống."});
            res.jsonV2(null, errorCode.sysErr, 'Lỗi hệ thống.');
        }
    }
};