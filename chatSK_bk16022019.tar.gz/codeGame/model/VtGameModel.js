/**
 * Created by conghuyvn8x on 8/4/2018.
 */
var redis = require('../config/redis').conRedis;
var listDb = require('../config/redis').listDb;
var listKey = require('../config/redis').listKey;
var VTHelper = require('../lib/VTHelper');
const async = require('async');
var validator = require('validator');
var logValidation = require('../config/log4j').logValid;
var logResponse = require('../config/log4j').logResponse;
var logErr = require('../config/log4j').logger;
var logger = require('../config/log4j').logger;
//var i18n = require("i18n");
var i18n = VTHelper.i18n;
var dateFormat = require('dateformat');
//const now = new Date();
//const errorCode = {succ:'00',loginfail:'01',sysErr:'02',validErr:'03'};
const errorCode = VTHelper.errCode;

//i18n.configure({
//    locales:['en', 'vi'],
//    directory: __dirname + '/i18n',
//    cookie: 'lang',
//    defaultLocale: 'vi'
//   });



exports.plusTurnsV2 = async function(data, keyRedis, callback) {
    const dbReport = listDb.dbReport;   // 3
    let keyNewYearBlacklistSet = listKey.keyNewYearBlacklistSet.replace('<programCode>',data.programCode);
    let checkNewYearBlacklistSet = await VTHelper.sismemberRedis(keyNewYearBlacklistSet,data.msisdn,dbReport);

    console.log('VTHelper.getKeyRedis a',keyNewYearBlacklistSet,keyNewYearBlacklistSet,data.msisdn,dbReport);
    //redis.incr(keyRedis);
    //let check = await VTHelper.getKeyRedisV2(keyRedis,0);
    //let check1 = await VTHelper.getKeyRedisV2('84973544564',0);
    //let check2 = await VTHelper.getKeyRedisV2('849735445645',0);
    //let a=0;
    //if(check1==false) a=1;
    //
    //console.log('VTHelper.getKeyRedis check1', check1);
    //console.log('VTHelper.getKeyRedis check2', check2);
    //console.log('VTHelper.getKeyRedis a', a);
    //const dbHistory = listDb.dbHistory; // 2
    //keyRedis = 'lpush:84386252255';
    //let lrange =await VTHelper.getLrange(keyRedis,0,3,dbHistory);
    //console.log('lrange 1',lrange);
    //let lpush =await VTHelper.lpush(keyRedis,data.msisdn,dbHistory);
    //console.log('lpush',lpush);
    //lrange =await VTHelper.getLrange(keyRedis,0,3,dbHistory);
    //console.log('lrange 2',lrange);
    callback(checkNewYearBlacklistSet);
}

/**
 * huync2: cong luot
 * @type {exports|module.exports}
 */
exports.plusTurns = async function (data, callback) {
    try{
        const dbTurn = listDb.dbTurn;
        //callback(true,5);
        redis.select(dbTurn, async function (err, res) {
            try{
                // you'll want to check that the select was successful here
                if (err) {
                    callback(errorCode.sysErr, i18n.__('Hệ thống bận.'));
                } else {
                    let now = new Date();
                    let dateNow= dateFormat(now, "yyyymmdd");
                    // Thực hiện cộng lượt vào Redis cho khách hàng
                    let keyTurnTotal = listKey.keyTurnTotal.replace('<programCode>',data.programCode).replace('<msisdn>', data.msisdn);
                    //keyTurnTotal=keyTurnTotal.replace('<programCode>',data.programCode).replace('<msisdn>', data.msisdn);
                    let keyTurnDaily = listKey.keyTurnDaily.replace('<programCode>',data.programCode).replace('<msisdn>', data.msisdn).replace('<YYYYMMDD>',dateNow);
                    // lay luot quay ngay
                    let numTurnDaily = await VTHelper.getKeyRedis(keyTurnDaily,dbTurn);
                    if(numTurnDaily===false) numTurnDaily=0;
                    //// tang luot quay tong
                    //redis.incrby(keyTurnTotal,parseInt(data.turns));
                    // tang luot quay tong
                    let numTurnTotal = await VTHelper.incrByRedis(keyTurnTotal,parseInt(data.turns),dbTurn,false);
                    // tra ve tong luot quay = ngay+tong
                    let total =parseInt(numTurnTotal)+parseInt(numTurnDaily);
                    // luu log <Tên hàm>|<service ID>|<Tên username>|<IP>|<Các params trừ username, pasword>|<Kết quả trả về>|<Nội dung lỗi nếu có>
                    //callback(true,5);
                    callback(errorCode.succ,total);
                }
            }catch(e){
                logger.error('plusTurns exception err: '+e);
                callback(errorCode.sysErr, i18n.__('Hệ thống bận.'));
            }

        });
    }catch(e){
        logger.error('plusTurns exception err: '+e);
        callback(errorCode.sysErr, i18n.__('Hệ thống bận.'));
    }

};

/**
 * huync2: tru luot
 * @type {exports|module.exports}
 */
exports.usingTurn = async function (data, callback) {
    try{
        const dbTurn = listDb.dbTurn;
        const dbReport = listDb.dbReport;   // 3
        //callback(true,5);
        redis.select(dbTurn, async function (err, res) {
            try{
// you'll want to check that the select was successful here
                if (err) {
                    callback(errorCode.sysErr, i18n.__('Hệ thống bận.'));
                } else {
                    // kiem tra thue bao trong blacklist newyear_blacklist_set:<programCode> <Số thuê bao có 84> , db 3
                    let keyNewYearBlacklistSet = listKey.keyNewYearBlacklistSet.replace('<programCode>',data.programCode);
                    let checkNewYearBlacklistSet = await VTHelper.sismemberRedis(keyNewYearBlacklistSet,data.msisdn,dbReport);
                    if(checkNewYearBlacklistSet==1){
                        // luu log <Tên hàm>|<service ID>|<Tên username>|<IP>|<Các params trừ username, pasword>|<Kết quả trả về>|<Nội dung lỗi nếu có>
                        callback(errorCode.VioBlacklistUsingTurn,i18n.__('Thuê bao bị chặn do vi phạm thể lệ chương trình'));
                    }else{
                        // Thực hiện trừ lượt vào Redis cho khách hàng
                        let now = new Date();
                        let dateNow= dateFormat(now, "yyyymmdd");
                        let keyTurnTotal = listKey.keyTurnTotal.replace('<programCode>',data.programCode).replace('<msisdn>', data.msisdn);
                        //keyTurnTotal=keyTurnTotal.replace('<programCode>',data.programCode).replace('<msisdn>', data.msisdn);
                        let keyTurnDaily = listKey.keyTurnDaily.replace('<programCode>',data.programCode).replace('<msisdn>', data.msisdn).replace('<YYYYMMDD>',dateNow);
                        // kiem tra tru luot ngay truoc
                        let numTurnDaily = await VTHelper.getKeyRedis(keyTurnDaily,dbTurn);
                        if(numTurnDaily===false) {
                            numTurnDaily = 0;
                        }
                        let checkUsingTurn=false;

                        if(numTurnDaily>0){
                            // tru luot ngay
                            redis.decr(keyTurnDaily);
                            checkUsingTurn=true;
                        }else{
                            // kiem tra tru luot tong
                            let numTurnTotal = await VTHelper.getKeyRedis(keyTurnTotal,dbTurn);
                            if(numTurnTotal>0){
                                // thuc hien tru luot tong
                                redis.decr(keyTurnTotal);
                                checkUsingTurn=true;
                            }
                        }

                        if(checkUsingTurn===true){
                            // tra ve so luot quay
                            numTurnDaily = await VTHelper.getKeyRedis(keyTurnDaily,dbTurn);
                            if(numTurnDaily===false) numTurnDaily=0;
                            let numTurnTotal = await VTHelper.getKeyRedis(keyTurnTotal,dbTurn);
                            if(numTurnTotal===false) numTurnTotal=0;
                            let total =parseInt(numTurnTotal)+parseInt(numTurnDaily);
                            //console.log('usingTurn',numTurnDaily, numTurnTotal, keyTurnDaily, keyTurnTotal);
                            //callback(true,5);
                            callback(errorCode.succ,total);
                        }else{
                            // tru ko thanh cong do het luot
                            callback(errorCode.overTurn, i18n.__("Trừ lượt không thành công do hết lượt."));
                        }
                    }
                }
            }catch(e){
                logger.error('usingTurn exception err: '+e);
                callback(errorCode.sysErr,i18n.__('Lỗi hệ thống'));
            }

        });
    }catch(e){
        logger.error('usingTurn exception err: '+e);
        callback(errorCode.sysErr,i18n.__('Lỗi hệ thống'));
    }

};

exports.addLogs = async function (data, callback) {
    try{
        const dbHistory = listDb.dbHistory; // 2
        const dbReport = listDb.dbReport;   // 3
        //callback(true,5);
        redis.select(dbReport, async function (err, res) {
            try{
// you'll want to check that the select was successful here
                if (err) {
                    callback(errorCode.sysErr, i18n.__('Hệ thống bận.'));
                } else {
                    // kiem tra thue bao trong blacklist newyear_blacklist_set:<programCode> <Số thuê bao có 84> , db 3
                    let keyNewYearBlacklistSet = listKey.keyNewYearBlacklistSet.replace('<programCode>',data.programCode);
                    let checkNewYearBlacklistSet = await VTHelper.sismemberRedis(keyNewYearBlacklistSet,data.msisdn,dbReport);
                    if(checkNewYearBlacklistSet==1){
                        // luu log <Tên hàm>|<service ID>|<Tên username>|<IP>|<Các params trừ username, pasword>|<Kết quả trả về>|<Nội dung lỗi nếu có>
                        callback(errorCode.VioBlacklistUsingTurn,i18n.__('Thuê bao bị chặn do vi phạm thể lệ chương trình'));
                    }else{
                        if(data.isSpecial==1){
                            // luu thuc hien check trung
                            let keySpecialGift=listKey.keySpecialGift.replace('<programCode>',data.programCode).replace('<msisdn>', data.msisdn);
                            redis.incr(keySpecialGift);
                        }
                        // luu log danh sach lich su thue bao
                        let keyMemberHis=listKey.keyMemberHis.replace('<programCode>',data.programCode).replace('<msisdn>', data.msisdn);
                        let dataMembreHis={
                            msisdn:data.msisdn,
                            giftCode:data.giftCode,
                            giftName:data.giftName,
                            winAt:data.winAt,
                            serviceId:data.serviceId,
                            luckyCode:data.luckyCode
                        };
                        let checkMemberHis = await VTHelper.lpush(keyMemberHis,JSON.stringify(dataMembreHis),dbHistory);

                        // luu log all
                        let keyLogAll = listKey.keyLogAll.replace('<programCode>',data.programCode);
                        let dataLog={
                            msisdn:data.msisdn,
                            giftType:data.giftType,
                            giftCode:data.giftCode,
                            giftName:data.giftName,
                            winAt:data.winAt,
                            serviceId:data.serviceId,
                            programCode:data.programCode,
                            smsContent:data.smsContent,
                            packageCode:data.packageCode,
                            voucherCode:data.voucherCode,
                            luckyCode:data.luckyCode,
                            value:data.value
                        };
                        let checkLogAll = await VTHelper.lpush(keyLogAll,JSON.stringify(dataLog),dbReport);
                        callback(errorCode.succ);
                    }
                }
            }catch(e){
                logger.error('addLogs exception err: '+e);
                callback(errorCode.sysErr,i18n.__('Lỗi hệ thống'));
            }
        });
    }catch(e){
        logger.error('addLogs exception err: '+e);
        callback(errorCode.sysErr,i18n.__('Lỗi hệ thống'));
    }

};

exports.getTurns = async function (data, callback) {
    try{
        const dbTurn = listDb.dbTurn;   // 1
        const dbReport = listDb.dbReport;   // 3
        const dbHistory = listDb.dbHistory;   // 2
        const dbLogLogin = listDb.dbLogLogin;   // 10

        // kiem tra thue bao trong blacklist newyear_blacklist_set:<programCode> <Số thuê bao có 84> , db 3
        let keyNewYearBlacklistSet = listKey.keyNewYearBlacklistSet.replace('<programCode>',data.programCode);
        let checkNewYearBlacklistSet = await VTHelper.sismemberRedis(keyNewYearBlacklistSet,data.msisdn,dbReport);

        if(checkNewYearBlacklistSet==1){
            // luu log <Tên hàm>|<service ID>|<Tên username>|<IP>|<Các params trừ username, pasword>|<Kết quả trả về>|<Nội dung lỗi nếu có>
            callback(errorCode.VioBlacklist,i18n.__('Thuê bao bị chặn do vi phạm thể lệ chương trình'));
        }else{
            let now = new Date();
            let timeNowTS = Math.round(new Date().getTime()/1000);
            let timeEnd= dateFormat(now, "yyyy-mm-dd")+' 23:59:59';
            let timeEndTS = Math.round(new Date(timeEnd).getTime()/1000);
            let expiredTime=timeEndTS-timeNowTS;
            let dateNow= dateFormat(now, "yyyymmdd");

            let keyTurnDaily = listKey.keyTurnDaily.replace('<programCode>',data.programCode).replace('<msisdn>', data.msisdn).replace('<YYYYMMDD>',dateNow);
            // kiem tra so luot dang nhap trong ngay
            let keyLoginTime=listKey.keyLoginTime.replace('<msisdn>', data.msisdn).replace('<YYYYMMDD>',dateNow);
            let numLoginTime = await VTHelper.incrRedis(keyLoginTime, dbLogLogin,expiredTime);
            if(parseInt(numLoginTime)===1){
                var numTurnDaily = await VTHelper.incrByRedis(keyTurnDaily,VTHelper.totalTurnInDay, dbTurn, expiredTime);
            }else{
                var numTurnDaily = await VTHelper.getKeyRedis(keyTurnDaily, dbTurn);
            }

            // lay luot ngay/toan CT
            let keyTurnTotal = listKey.keyTurnTotal.replace('<programCode>',data.programCode).replace('<msisdn>', data.msisdn);
            let numTurnTotal = await VTHelper.getKeyRedis(keyTurnTotal, dbTurn);
            if(numTurnTotal===false) numTurnTotal=0;
            //let keyTurnDaily = listKey.keyTurnDaily.replace('<programCode>',data.programCode).replace('<msisdn>', data.msisdn);
            //let numTurnDaily = await VTHelper.getKeyRedis(keyTurnDaily, dbTurn);

            if(numTurnDaily===false) numTurnDaily=0;
            let total= parseInt(numTurnTotal)+parseInt(numTurnDaily);
            // luu log <Tên hàm>|<service ID>|<Tên username>|<IP>|<Các params trừ username, pasword>|<Kết quả trả về>|<Nội dung lỗi nếu có>
            callback(errorCode.succ,total);
        }
    }catch(e){
        logger.error('getTurns exception err: '+e);
        callback(errorCode.sysErr,i18n.__('Lỗi hệ thống'));
    }

};



/**
 * ham thuc hien kiem tra isdn da share facebook chua
 */
exports.checkShareFb = async function (data, callback){
    try{
        var keyShareFb = listKey.keyShareFb.replace('<programCode>',data.programCode).replace('<msisdn>',data.msisdn);
        redis.select(listDb.dbShare)
        redis.get(keyShareFb, await function(err, shareTotal){
            if (err) {
                logValidation.error('checkShareFb' + '|' + serviceId + '|' + msisdn + '|' + data.ip + '|' + JSON.stringify(data) + '|' + err);
                callback(errorCode.sysErr, i18n.__('Lỗi hệ thống'));
            } else {
                if(shareTotal >=1){
                    callback(errorCode.succ, 1);
                }else{
                    callback(errorCode.succ, 0);
                }
            }
        });
    }catch(e){
        logErr.error('getTurns exception err: '+e);
        callback(errorCode.sysErr,i18n.__('Lỗi hệ thống'));
    }
};

/**
 * ham thuc hien add log share facebook
 */
exports.shareFb = async function (data, callback){
    try{
        var keyShare = listKey.keyShareFb.replace('<programCode>',data.programCode).replace('<msisdn>',data.msisdn);
        var keyTurn = listKey.keyTurnTotal.replace('<programCode>',data.programCode).replace('<msisdn>',data.msisdn);
        redis.on('error', function(err) {
            logErr.error('Redis error: ' + err);
            callback(errorCode.sysErr,i18n.__('Lỗi hệ thống'));
        });
        redis.select(listDb.dbShare);
        redis.get(keyShare, function (err, share) {
            try{
                if(err){
                    logResponse.error('addLogShareFb' + '|'+ data.serviceId + '|' + data.msisdn + '|' + data.ip + '|' + JSON.stringify(data) + '|' + '00-not share');
                    callback(errorCode.sysErr,i18n.__('Lỗi hệ thống'));
                }else{
                    if(share >= 1){
                        logResponse.info('addLogShareFb' + '|' + data.serviceId + '|' + data.msisdn + '|' + data.ip + '|' + JSON.stringify(data) + '|' + '01-shared');
                        callback('04',i18n.__('Thuê bao đã được cộng lượt share.'));
                    }else{
                        //lay luot choi cua KH
                        redis.incr(keyShare, function(err, totalShare){
                            try{
                                if (err) {
                                    logResponse.info('addLogShareFb' + '|'+ data.serviceId + '|' + data.msisdn + '|' + data.ip + '|' + JSON.stringify(data) + '|' + '02-add share fail.'+ err);
                                    callback(errorCode.sysErr,i18n.__('Lỗi hệ thống'));
                                } else {
                                    if(totalShare >1){
                                        logResponse.info('addLogShareFb' + '|'+ data.serviceId + '|' + data.msisdn + '|' + data.ip + '|' + JSON.stringify(data) + '|' + '02-add turn fail.'+ err);
                                        callback('04', i18n.__('Thuê bao đã được cộng lượt share.'));
                                    }else{
                                        redis.select(listDb.dbTurn);
                                        redis.incr(keyTurn, function(err, turn){
                                            try{
                                                if (err) {
                                                    //decre share face
                                                    redis.select(listDb.dbTurn);
                                                    redis.decr(keyShare, function(err){
                                                        if (err) {
                                                            logResponse.info('addLogShareFb' + '|'+ data.serviceId + '|' + data.msisdn + '|' + data.ip + '|' + JSON.stringify(data) + '|' + '02-fail decre share face when incre turn fail.'+ err);
                                                            callback(errorCode.sysErr,i18n.__('Lỗi hệ thống'));
                                                        } else {
                                                            logResponse.info('addLogShareFb' + '|'+ data.serviceId + '|' + data.msisdn + '|' + data.ip + '|' + JSON.stringify(data) + '|' + '02-sucess decre share face when incre turn fail');
                                                            callback(errorCode.sysErr,i18n.__('Lỗi hệ thống'));
                                                        }
                                                    })
                                                } else {
                                                    let now = new Date();
                                                    let dateNow= dateFormat(now, "yyyymmdd");
                                                    let keyTurnDaily = listKey.keyTurnDaily.replace('<programCode>',data.programCode).replace('<msisdn>', data.msisdn).replace('<YYYYMMDD>',dateNow);
                                                    redis.select(listDb.dbTurn);
                                                    redis.get(keyTurnDaily, function (err, numTurnDaiLy) {
                                                        if(err){
                                                            logResponse.info('addLogShareFb' + '|'+ data.serviceId + '|' + data.msisdn + '|' + data.ip + '|' + JSON.stringify(data) + '|' + '02-get daily turn fail');
                                                            callback(errorCode.sysErr,i18n.__('Lỗi hệ thống'));
                                                        } else{
                                                            var totalTurn = 0;
                                                            if(numTurnDaiLy){
                                                                totalTurn = parseInt(turn) + parseInt(numTurnDaiLy);
                                                            }else{
                                                                totalTurn = parseInt(turn);
                                                            }
                                                            logResponse.info('addLogShareFb' + '|'+ data.serviceId + '|' + data.msisdn + '|' + data.ip + '|' + JSON.stringify(data) + '|' + '02-share success.total turn '+ totalTurn);
                                                            callback(errorCode.succ, totalTurn);
                                                        }
                                                    });
                                                }
                                            }catch(e){
                                                logErr.error('shareFb exception err: '+e);
                                                callback({data:null, errorCode: errorCode.sysErr, message: 'Lỗi hệ thống'});
                                            }
                                        })
                                    }
                                }
                            }catch(e){
                                logErr.error('shareFb exception err: '+e);
                                callback({data:null, errorCode: errorCode.sysErr, message: 'Lỗi hệ thống'});
                            }

                        });
                    }
                }
            }catch(e){
                logErr.error('shareFb exception err: '+e);
                callback({data:null, errorCode: errorCode.sysErr, message: 'Lỗi hệ thống'});
            }

        });
    }catch(e){
        logErr.error('shareFb exception err: '+e);
        callback({data:null, errorCode: errorCode.sysErr, message: 'Lỗi hệ thống'});
    }
}


/**
 * ham thuc hien kiem tra isdn da đã nhận quà đặc biệt chua
 */
exports.checkGiftRewarded =  function (data, callback){
    var isValid = validParam(data,'checkGiftRewarded');
    if(isValid.errorCode == errorCode.succ){
        try{
            var keySpecialGift = listKey.keySpecialGift.replace('<programCode>',data.programCode).replace('<msisdn>',data.msisdn);
            redis.select(listDb.dbReport);
            redis.get(keySpecialGift, function(err, recieved){
                if (err) {
                    logValidation.error('checkGiftRewarded' + '|' + serviceId + '|' + msisdn + '|' + data.ip + '|' + JSON.stringify(data) + '|' + err);
                    callback(errorCode.sysErr, i18n.__('Lỗi hệ thống'));
                } else {
                    if(recieved >=1){
                        callback(errorCode.succ,recieved);
                    }else{
                        callback(errorCode.succ, 0);
                    }
                }
            });
        }catch(e){
            logErr.error('checkGiftRewarded exception err: '+e);
            callback(errorCode.sysErr,i18n.__('Lỗi hệ thống'));
        }
    }else{
        callback(errorCode.validErr, isValid.message);
    }

}


/**
 * ham thuc hien lấy danh sách bảng vàng
 */
exports.getGoldTable = async  function (data, callback){
    try{
        var keyRedis = listKey.keyGoldTable.replace('<programCode>',data.programCode);
        //validate
        let result = await validParam(data, 'getGoldTable', null);
        if(result.errorCode == errorCode.succ){
            let page = data.page;
            let pageSize = data.pageSize;
            if(typeof data.page == 'undefined' ||page <=0){
                page = 1;
            }
            if(typeof data.pageSize == 'undefined' ||pageSize <= 0){
                pageSize = 10;
            }
            let start = pageSize*(page - 1);
            let end = pageSize*page;
            redis.on('error', function(err) {
                logErr.error('Redis error: ' + err);
                callback({errorCode: errorCode.sysErr, message:i18n.__('Lỗi hệ thống')});
            });
            redis.select(listDb.dbReport);
            redis.lrange(keyRedis, start, end, function(err, value){
                try{
                    if(err){
                        logResponse.error('getGoldTable' + '|' + data.serviceId + '|' + data.ip + '|' + JSON.stringify(data) + '|' + '02-get redis error '+ err);
                        callback({errorCode: errorCode.sysErr, message:i18n.__('Lỗi hệ thống')});
                    }else{
                        var dataResult = [];
                        if(value.length){
                            value.forEach(function (item) {
                                dataResult.push(JSON.parse(item));
                            })
                        }else{
                            dataResult=null;
                        }
                        logResponse.info('getGoldTable'+'|' + data.serviceId + '|' + data.ip + '|' + JSON.stringify(value) + '|' + '00- get his gift success');
                        callback({errorCode: errorCode.succ,message:i18n.__('Thành công'), data: dataResult});
                    }
                }catch(e){
                    logErr.error('getGoldTable exception err: '+e);
                    callback({data:null, errorCode:errorCode.sysErr, message: i18n.__('Lỗi hệ thống')});
                }
            });
        }else {
            callback({data:null, errorCode:errorCode.validErr, message: result.message});
        }
    }catch(e){
        logErr.error('getGoldTable exception err: '+e);
        callback({data:null, errorCode:errorCode.sysErr, message: i18n.__('Lỗi hệ thống')});
    }

}


/**
 * ham thuc hien lấy danh lich su mo qua
 */
exports.getGiftList = async function (data, callback){
    try{
        var keyRedis = listKey.keyGiftList.replace('<programCode>',data.programCode).replace('<msisdn>',data.msisdn);
        //validate
        if(!data.msisdn){
            let message = i18n.__('Tham số msisdn không được để trống.');
            logValidation.error('checkGiftRewarded' + '|' + data.serviceId + '|' + data.msisdn + '|' + data.ip + '|' + JSON.stringify(data) + '|' + message);
            callback({data:null, errorCode:errorCode.validErr, message: message});
        }else{
            let result = await validParam(data, 'getGiftList',null);

            if(result.errorCode == errorCode.succ){
                let page = data.page;
                let pageSize = data.pageSize;
                if(typeof data.page == 'undefined' ||page <=0){
                    page = 1;
                }
                if(typeof data.pageSize == 'undefined' ||pageSize <= 0){
                    pageSize = 10;
                }
                let start = pageSize*(page - 1);
                let end = pageSize*page;
                redis.on('error', function(err) {
                    logErr.error('Redis error: ' + err);
                    callback({errorCode: errorCode.sysErr, message:i18n.__('Lỗi hệ thống')});
                });
                redis.select(listDb.dbHistory);
                redis.lrange(keyRedis, start, end, function(err, value){
                    try{
                        if(err){
                            logResponse.error('getGiftList'+'|' + data.serviceId + '|' + data.msisdn + '|' + data.ip + '|' + JSON.stringify(value) + '|' + '02- get his gift error' + err);
                            callback({errorCode: errorCode.sysErr, message:i18n.__('Lỗi hệ thống')});
                        }else{
                            var dataResult = [];
                            if(value.length){
                                value.forEach(function (item) {
                                    dataResult.push(JSON.parse(item));
                                })
                            }else{
                                dataResult=null;
                            }
                            logResponse.info('getGiftList'+'|' + data.serviceId + '|' + data.msisdn + '|' + data.ip + '|' + JSON.stringify(value) + '|' + '00- get his gift success');
                            callback({errorCode: errorCode.succ,message:i18n.__('Thành công'), data: dataResult});
                        }
                    }catch(e){
                        logErr.error('getGiftList exception err: '+e);
                        callback({data:null, errorCode: errorCode.validErr, message: 'Lỗi hệ thống'});
                    }
                });
            } else {
                callback({data:null, errorCode:errorCode.validErr, message: result.message});
            }
        }
    }catch(e){
        logErr.error('getGiftList exception err: '+e);
        callback({data:null, errorCode: errorCode.sysErr, message: 'Lỗi hệ thống'});
    }
}

/**
 *  ham valid thong tin truyen vao
 * @param data (serviceId, programCode, msisdn, page, pageSize, giftCode )
 * @param callback
 */
validParam =  function (data, action) {
    if(typeof data.page !== 'undefined' && !validator.isInt(data.page,{min:0, max:9999})){
        let message = i18n.__('Tham số page không hợp lệ.');
        let serviceId = '';
        if(typeof data.serviceId !== 'undefined'){
            serviceId = data.serviceId;
        }
        let msisdn = '';
        if(typeof data.serviceId !== 'undefined'){
            msisdn = data.msisdn;
        }
        logValidation.error(action + '|' + serviceId + '|' + msisdn + '|' + data.ip + '|' + JSON.stringify(data) + '|' + message);
        return({data:null, errorCode:errorCode.validErr, message: message});
    }else
    if(typeof data.pageSize !== 'undefined' && !validator.isInt(data.pageSize,{min:0, max:9999})){
        let message = i18n.__('Tham số pageSize không hợp lệ.');
        let serviceId = '';
        if(typeof data.serviceId !== 'undefined'){
            serviceId = data.serviceId;
        }
        let msisdn = '';
        if(typeof data.serviceId !== 'undefined'){
            msisdn = data.msisdn;
        }
        logValidation.error(action + '|' + serviceId + '|' + msisdn + '|' + data.ip + '|' + JSON.stringify(data) + '|' + message);
        return({data:null, errorCode:errorCode.validErr, message: message});
    }else
    if(typeof data.programCode == 'undefined'){
        //if(typeof data.programCode == 'undefined' ||!validator.isAlphanumeric(data.programCode)){
        let message = i18n.__('Tham số programCode không hợp lệ.');
        let serviceId = '';
        if(typeof data.serviceId !== 'undefined'){
            serviceId = data.serviceId;
        }
        let msisdn = '';
        if(typeof data.serviceId !== 'undefined'){
            msisdn = data.msisdn;
        }
        logValidation.error(action + '|' + serviceId + '|' + msisdn + '|' + data.ip + '|' + JSON.stringify(data) + '|' + message);
        return({data:null, errorCode:errorCode.validErr, message: message});
    }else
    if(!validator.isLength(data.programCode,{min:1, max:50})){
        let message = i18n.__('Tham số programCode maxlength không hợp lệ.');
        let serviceId = '';
        if(typeof data.serviceId !== 'undefined'){
            serviceId = data.serviceId;
        }
        let msisdn = '';
        if(typeof data.serviceId !== 'undefined'){
            msisdn = data.msisdn;
        }
        logValidation.error(action + '|' + serviceId + '|' + msisdn + '|' + data.ip + '|' + JSON.stringify(data) + '|' + message);
        return({data:null, errorCode:errorCode.validErr, message: message});
    }else
    if(typeof data.serviceId == 'undefined' || !validator.isAlphanumeric(data.serviceId)){
        let message = i18n.__('Tham số serviceId không hợp lệ.');
        let serviceId = '';
        if(typeof data.serviceId !== 'undefined'){
            serviceId = data.serviceId;
        }
        let msisdn = '';
        if(typeof data.serviceId !== 'undefined'){
            msisdn = data.msisdn;
        }
        logValidation.error(action + '|' + serviceId + '|' + msisdn + '|' + data.ip + '|' + JSON.stringify(data) + '|' + message);
        return({data:data, errorCode:errorCode.validErr, message:message});
    }else
    if(!validator.isLength(data.serviceId,{min:1, max:50})){
        let message = i18n.__('Tham số serviceId maxlength không hợp lệ.');
        let serviceId = '';
        if(typeof data.serviceId !== 'undefined'){
            serviceId = data.serviceId;
        }
        let msisdn = '';
        if(typeof data.serviceId !== 'undefined'){
            msisdn = data.msisdn;
        }
        logValidation.error(action + '|' + serviceId + '|' + msisdn + '|' + data.ip + '|' + JSON.stringify(data) + '|' + message);
        return({data:null, errorCode:errorCode.validErr, message: message});
    }else{
        return({data:data, errorCode: errorCode.succ, message: 'data correct'});
    }
}
