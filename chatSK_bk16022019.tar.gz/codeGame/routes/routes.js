/**
 * Created by conghuyvn8x on 8/4/2018.
 */
module.exports = function (app) {
    var gameControl = require('../controllers/GameController');
    //var mw = require('../controllers/auth');
    //app.use(mw([]));

    // vtImageControl Routes
    app.route('/plusTurnsV2').post(gameControl.plusTurnsV2);
    app.route('/plusTurns').post(gameControl.plusTurns);
        //.get(gameControl.getPlusTurn);
    app.route('/usingTurn').post(gameControl.usingTurn);
    app.route('/addLogs').post(gameControl.addLogs);
    app.route('/getTurns').post(gameControl.getTurns);
    app.route('/checkShareFb').post(gameControl.checkShareFb);
    app.route('/addLogShareFb').post(gameControl.shareFb);
    app.route('/checkGiftRewarded').post(gameControl.checkGiftRewarded);
    app.route('/getGoldTable').post(gameControl.getGoldTable);
    app.route('/getGiftList').post(gameControl.getGiftList);
};